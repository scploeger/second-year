Student Information
####################
Spencer Ploeger
0969141
sploeger@uoguelph.ca

Program Description
####################
CIS2520 - Lab 2
Book and boardgame store

Additonal Program  Details
####################
type 'make' in the root direcitry to build and compile the program
run 'runMe' from the ./bin/ folder to run the program
