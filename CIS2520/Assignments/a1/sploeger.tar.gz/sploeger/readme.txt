Student Information
####################
Spencer Ploeger
sploeger@uoguelph.ca
0969141

Program Description
###################
Assignment 1 - CIS2520, University of Guelph
Last Edited: Oct/10/2017
- Traffic simulator program using my own doubly linked list and a seperate simulation file.

Additional Program Details
##########################
TO RUN THE MAIN: from the main directory of teh program, open terminal and type 'make' and press 
					enter, then type 'make run' and press enter. **to update the data file to use
					open up the MAKEFILE and change the file directory to use and then save.

TO RUN THE MAIN TEST: from the main directory of teh program, open terminal and type 'make' and press 
					enter, then type 'make test' and press enter.