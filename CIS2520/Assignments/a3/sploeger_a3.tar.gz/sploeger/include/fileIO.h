#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "hashTableAPI.h"

void loadDict( char* filename, HTable* thisTable);
void loadUsr( char* filename, HTable* thisTable, char* name);