Student Information
####################
Spencer Ploeger
sploeger@uoguelph.ca
0969141

Program Description
###################
Assignment 2 - CIS2520, University of Guelph
Last Edited: Oct/22/2017
- Hospital ER simulator, using my own priority queue API, modified from my linked list API from Assignment 1.

Additional Program Details
##########################
TO RUN THE MAIN: from the main directory of the program, open terminal and type 'make' and press enter, then type 'make run' and press enter. **to update the data file to use
open up the MAKEFILE and change the file directory to use and then save.

TO RUN THE MAIN TEST: from the main directory of teh program, open terminal and type 'make' and press enter, then type 'make test' and press enter.

OUTPUT FILE:  Data is output to a file in ./assets/ called "output.txt"

Assumptions
###########
Although not explicity shown in the assignment discription, I took it as the data has to be written to a file after the simulation is run, hence the output.txt file.